function App() {
  return (
    <div>
      <h1>Chekou é peso</h1>
      <p>Meu projeto está funcionando!</p>
    </div>
  );
}

export default App;